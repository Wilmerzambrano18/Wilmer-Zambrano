import dash
import dash_core_components as dcc
import dash_html_components as html
import pandas as pd
import numpy as np
import plotly.express as px
import seaborn as sns
import altair as alt

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)

df_all = pd.read_csv('df_all.csv', 
                 sep = ',',dtype={
                     'Nit Entidad': str,
                     'id_nucleo':str,
                     'id_sexo':str
                 })
df_all.drop(["Unnamed: 0"],axis = 1)

columns = ["sector_ies",
            "ies",
           "caracter_ies",
           "depto_de_domicilio_ies",
           "nivel_academico",
           "nivel_de_formacion",
           "metodologia",
           "area_de_conocimiento",
           'dpto_del_programa',
           "sexo",
           "año",
           "semestre",
           "admitidos"       
           ]
df_final = df_all.copy()
df_final = df_final[columns]
df_final.head()

df_final["caracter_ies"] = df_final["caracter_ies"].replace("Universidad","UNIVERSIDAD")
df_final["caracter_ies"] = df_final["caracter_ies"].replace(("Institución Universitaria/Escuela Tecnológica","INSTITUCION UNIVERSITARIA/ESCUELA TECNOLOGICA"),"INSTITUCIÓN UNIVERSITARIA/ESCUELA TECNOLÓGICA")
df_final["caracter_ies"] = df_final["caracter_ies"].replace(("Institución Tecnológica","INSTITUCION TECNOLOGICA"),"INSTITUCIÓN TECNOLÓGICA")
df_final["caracter_ies"] = df_final["caracter_ies"].replace(("Institución Técnica Profesional","INSTITUCION TECNICA PROFESIONAL"),"INSTITUCIÓN TÉCNICA PROFESIONAL")
df_final["depto_de_domicilio_ies"] = df_final["depto_de_domicilio_ies"].replace(("BOGOTA D.C","BOGOTA D.C."),"BOGOTÁ D.C.")
df_final["depto_de_domicilio_ies"] = df_final["depto_de_domicilio_ies"].replace("GUAJIRA","LA GUAJIRA")
df_final["depto_de_domicilio_ies"] = df_final["depto_de_domicilio_ies"].replace("ATLANTICO","ATLÁNTICO")
df_final["depto_de_domicilio_ies"] = df_final["depto_de_domicilio_ies"].replace("BOYACA","BOYACÁ")
df_final["depto_de_domicilio_ies"] = df_final["depto_de_domicilio_ies"].replace("CAQUETA","CAQUETÁ")
df_final["depto_de_domicilio_ies"] = df_final["depto_de_domicilio_ies"].replace("CHOCO","CHOCÓ")
df_final["depto_de_domicilio_ies"] = df_final["depto_de_domicilio_ies"].replace("CORDOBA","CÓRDOBA")
df_final["depto_de_domicilio_ies"] = df_final["depto_de_domicilio_ies"].replace("QUINDIO","QUINDÍO")
df_final["depto_de_domicilio_ies"] = df_final["depto_de_domicilio_ies"].replace(("SAN ANDRES Y PROVIDENCIA","ARCHIPIÉLAGO DE SAN ANDRÉS, PROVIDENCIA Y SANTA CATALINA","SAN ANDRES Y PROVI"),"SAN ANDRÉS Y PROVIDENCIA")
df_final["depto_de_domicilio_ies"] = df_final["depto_de_domicilio_ies"].replace(("NARINO","NARINIO"),"NARIÑO")
df_final["depto_de_domicilio_ies"] = df_final["depto_de_domicilio_ies"].replace("BOLIVAR","BOLÍVAR")
df_final["nivel_de_formacion"] = df_final["nivel_de_formacion"].replace("Universitaria","UNIVERSITARIA")
df_final["nivel_de_formacion"] = df_final["nivel_de_formacion"].replace(("Tecnológica","TECNOLOGICA"),"TECNOLÓGICA")
df_final["nivel_de_formacion"] = df_final["nivel_de_formacion"].replace(("Especialización Universitaria","ESPECIALIZACION"),"ESPECIALIZACIÓN UNIVERSITARIA")
df_final["nivel_de_formacion"] = df_final["nivel_de_formacion"].replace(("Maestría","MAESTRIA"),"MAESTRÍA")
df_final["nivel_de_formacion"] = df_final["nivel_de_formacion"].replace(("Formación técnica profesional","FORMACION TECNICA PROFESIONAL"),"FORMACIÓN TÉCNICA PROFESIONAL")
df_final["nivel_de_formacion"] = df_final["nivel_de_formacion"].replace("Especialización Médico Quirúrgica","ESPECIALIZACIÓN MÉDICO QUIRÚRGICA")
df_final["nivel_de_formacion"] = df_final["nivel_de_formacion"].replace("Doctorado","DOCTORADO")
df_final["nivel_de_formacion"] = df_final["nivel_de_formacion"].replace("Especialización Tecnológica","ESPECIALIZACIÓN TECNOLÓGICA")
df_final["nivel_de_formacion"] = df_final["nivel_de_formacion"].replace(("Especialización Técnico Profesion","Especialización Técnico Profesional"),"ESPECIALIZACIÓN TÉCNICO PROFESIONAL")
df_final["metodologia"] = df_final["metodologia"].replace("Presencial","PRESENCIAL")
df_final["metodologia"] = df_final["metodologia"].replace(("Distancia (tradicional)","DISTANCIA (TRADICION"),"DISTANCIA (TRADICIONAL)")
df_final["metodologia"] = df_final["metodologia"].replace(("Distancia (virtual)","DISTANCIA (VIRTUAL)"),"VIRTUAL")
df_final["area_de_conocimiento"] = df_final["area_de_conocimiento"].replace(("Economía, administración, contaduría y afines","ECONOMIA ADMINISTRACION CONTADURIA Y AFINES"),"ECONOMÍA, ADMINISTRACIÓN, CONTADURÍA Y AFINES")
df_final["area_de_conocimiento"] = df_final["area_de_conocimiento"].replace(("Ingeniería, arquitectura, urbanismo y afines","INGENIERIA ARQUITECTURA URBANISMO Y AFINES"),"INGENIERÍA, ARQUITECTURA, URBANISMO Y AFINES")
df_final["area_de_conocimiento"] = df_final["area_de_conocimiento"].replace("Ciencias sociales y humanas","CIENCIAS SOCIALES Y HUMANAS")
df_final["area_de_conocimiento"] = df_final["area_de_conocimiento"].replace("Ciencias de la salud","CIENCIAS DE LA SALUD")
df_final["area_de_conocimiento"] = df_final["area_de_conocimiento"].replace("Bellas artes","BELLAS ARTES")
df_final["area_de_conocimiento"] = df_final["area_de_conocimiento"].replace(("Ciencias de la educación","CIENCIAS DE LA EDUCACION"),"CIENCIAS DE LA EDUCACIÓN")
df_final["area_de_conocimiento"] = df_final["area_de_conocimiento"].replace(("Agronomía, veterinaria y afines","AGRONOMIA VETERINARIA Y AFINES"),"AGRONOMÍA, VETERINARIA Y AFINES")
df_final["area_de_conocimiento"] = df_final["area_de_conocimiento"].replace(("Matemáticas y ciencias naturales","MATEMATICAS Y CIENCIAS NATURALES"),"MATEMÁTICAS Y CIENCIAS NATURALES")
df_final["sexo"] = df_final["sexo"].replace(("Hombre","HOMBRE"),"MASCULINO")
df_final["sexo"] = df_final["sexo"].replace(("Mujer","MUJER"),"FEMENINO")
df_final["sexo"] = df_final["sexo"].replace("Sin información","NO INFORMA")

df_final = df_final.rename(columns={'area_de_conocimiento':'Área de conocimiento'})

available_ciudades = df_final['depto_de_domicilio_ies'].unique()
available_ciudades2 = df_final['depto_de_domicilio_ies'].unique()
available_ciudades3 = df_final['depto_de_domicilio_ies'].unique()
available_Area = df_final['Área de conocimiento'].unique()
available_año = df_final['año'].unique()
available_año1 = df_final['año'].unique()
df_final_bog = df_final[(df_final['dpto_del_programa'] == "BOGOTÁ D.C.")] 
available_ins = df_final_bog['ies'].unique()
#df_final_con = df_final[df_final.area_de_conocimiento.isin(['INGENIERIA ARQUITECTURA URBANISMO Y AFINES',
#       'AGRONOMIA VETERINARIA Y AFINES', 'BELLAS ARTES',
#       'CIENCIAS DE LA SALUD', 'CIENCIAS SOCIALES Y HUMANAS',
#       'ECONOMIA ADMINISTRACION CONTADURIA Y AFINES',
#       'MATEMATICAS Y CIENCIAS NATURALES', 'CIENCIAS DE LA EDUCACION',
#       'Ingeniería, arquitectura, urbanismo y afines',
#       'Agronomía, veterinaria y afines', 'Bellas artes',
#       'Ciencias de la salud', 'Ciencias sociales y humanas',
#       'Economía, administración, contaduría y afines',
#       'Matemáticas y ciencias naturales', 'Ciencias de la educación',
#       'CIENCIAS DE LA EDUCACIÓN',
#       'ECONOMÍA, ADMINISTRACIÓN, CONTADURÍA Y AFINES',
#       'INGENIERÍA, ARQUITECTURA, URBANISMO Y AFINES',
#       'AGRONOMÍA, VETERINARIA Y AFINES',
#       'MATEMÁTICAS Y CIENCIAS NATURALES'])]

available_conocimiento=df_final['Área de conocimiento'].unique()
uvailable_sex = df_final['sexo'].unique()

df_final4 = pd.pivot_table(df_final,index=["Área de conocimiento","sexo","depto_de_domicilio_ies"],aggfunc=np.sum)
Con = pd.DataFrame(df_final4)
Con.reset_index(inplace=True)

df_final5 = pd.pivot_table(df_final,index=["caracter_ies","sexo","nivel_academico","depto_de_domicilio_ies"],aggfunc=np.sum)
Con2 = pd.DataFrame(df_final5)
Con2.reset_index(inplace=True)
### Visualización 1





####################################################################





app.layout = html.Div(
    children=[
        html.H1(children="Visualizaciones corte 3",
            style = {
                        'textAlign': 'center',
            }),
        html.H3(children="Base de Datos SNIES"),
        html.P(
            children="La base cuenta con información de los estudiantes " 
            "admitidos a institutos de educación superior del año 2014 a 2019."
            ),
        html.P(
            children="En cuento a la depuración de la base, no se encontraron valores faltantes ni registros repetidos " 
            "para algunas variables como sexo, nivel de formación o departamento de domicilio, metodología entre otras, "
            "toco recategorizarlas."
            ),
        html.P(
            "En la siguiente tabla se muestran las variables con las que se trabajó "
            "para obtener las visualizaciones."
            ),
        html.Div([
            html.Table([
                html.Thead(
                    html.Tr([html.Th(col) for col in df_final.columns])
                ),
                html.Tbody([
                    html.Tr([
                        html.Td(df_final.iloc[i][col]) for col in df_final.columns
                    ]) for i in range(min(len(df_final), 4))
                
            ]),
        ], className='four columns'),
    ], className='row'),
        html.H3(children="Visualizaciones Jacobo Avila"),
        html.P(
            children="En ésta visualización se puede observar "
            "la distribución de la cantidad de admitidos para todos los "
            "departamentos de colombia (entre los años 2014-2019) desagregado por "
            "el area de conocimiento y el sexo."
            ),
        html.Div([
            html.H3(children='visualización 1'),#
            html.Div(children='''
                
                Departamentos
            
            '''),#
            dcc.Dropdown(
                id='crossfilter_departamento',
                 options=[{'label': x, 'value': x} 
                            for x in available_ciudades],
                value = ['BOYACÁ'],
                clearable=False
                ),
            dcc.Graph(
                id='example-graph-1'
            ),  
        ]),
        html.P(
            children="En ésta visualización se puede observar "
            "la proprcion de admitidos para todos los departamentos"
            " de colombia (entre los años 2014-2019) jerarquizados de "
            "la siguiente manera : 1 sexo , 2 nivel academico y 3 tipo de institución"
            ),
        html.Div([
            html.H3(children='Visualización 2'),#
            html.Div(children='''
                Departamentos
            '''),#
            dcc.Dropdown(id='crossfilter_departamento2',
                options=[{'label': i, 'value': i} 
                            for i in available_ciudades2],
                value = ['BOYACÁ'],
                clearable=False
                ),
            dcc.Graph(
                id='example-graph-2'
            ),  
        ]),

        html.H3(children="Visualizaciones Wilmer Zambrano"),
        html.Div([
            
            html.H4(children='Treemap por departamento'),
            html.P(
            children="Se puede ver la cantidad de estudiantes admitidos clasificado primero por tipo de metodologia "
            "seguido del semestre en que ingreso, 1 para el primer semestre del año y 2 para el segundo."
            ),
            html.Div(children='''
                Seleccione el Departamento:
            '''),#
            dcc.Dropdown(
                id='crossfilter_ciudad3',
                options=[{'label': i, 'value': i} for i in available_ciudades3],
                value='ANTIOQUIA'
            ),
            dcc.Graph(
                id='example-graph-3'
            ),  
        ], className='eight columns'),
                html.Div([ 
            html.Div([
                html.H4(children='Visualizacion de barras apiladas por año'),
                html.P(
            children="Se muestra un gráfico de barras, donde el eje X muestra la cantidad de estudiantes admitidos, "
            "además cada barra corresponde a MASCULINO y la otra a FEMENINO, en cuanto al sector ies oficial y privado se diferecian "
            "cada uno con un color diferente."
            ),
                html.Div(children='''
                Seleccione el Año
                '''),#
                dcc.Checklist(id='crossfilter_2',
                 options=[{'label': i, 'value': i} 
                                for i in available_año],
                    value = ['2014'],
                    labelStyle={'display': 'inline-block'}
                    ),
                dcc.Graph(
                    id='example-graph-4'
                ),  
            ], className='eight columns'),
        ], className='row'),#



#########################################################################3

        html.H3(children="Visualizaciones Alejandro"),
        html.Div([
            html.H4(children='Treemap por Universidad de Cundinamarca'),
            html.P(
            children="Se observa la cantidad de estudiantes admitidos de solo el departamento de Cundinamarca clasificado primero por nivel de formación "
            "seguido del genero en que ingreso. "
            ),
            html.Div(children='''
                Seleccione el Departamento
            '''),#
            dcc.Dropdown(
                id='crossfilter_ciudad5',
                options=[{'label': i, 'value': i} for i in available_ins],
                value='UNIVERSIDAD NACIONAL DE COLOMBIA'
            ),
            dcc.Graph(
                id='example-graph-5'
            ),  
        ], className='eight columns'),
##########################################################################333

        html.Div([ 
            html.Div([
            html.H4(children='Mapa de calor por área de conocimiento y sexo'),#
            html.P(
            children="El Mapa muestra la cantidad de estudiantes admitidos por género y por área de conocimiento "
            "Adicionalmente cuando se seleccionan más de dos áreas de conocimiento, se reorganizan por orden alfabético."
            ),
            html.Div(children='''
                
                Seleccione el área de conocimiento:
            
            '''),#
            dcc.Dropdown(
                id='crossfilter_6',
                 options=[{'label': x, 'value': x} 
                            for x in available_conocimiento],
                value = ['BELLAS ARTES'],
                multi = True
                ),
            html.Div(children='''
                
                Seleccione sexo:
            
            '''),#
            dcc.Dropdown(
                id='crossfilter_mod_sex',
                 options=[{'label': x, 'value': x} 
                            for x in uvailable_sex],
                value = ['FEMENINO'],
                multi = True
                ),
            dcc.Graph(
                id='example-graph-6'
            ),  
        ], className='eight columns'),
    ], className='row'),#
     
])
        

######################################################################################
## Viz 1 jacobo
@app.callback(
    dash.dependencies.Output('example-graph-1', 'figure'),
    dash.dependencies.Input('crossfilter_departamento', 'value')
    )
def update_bar_chart(depto_de_domicilio_ies):
    mask = Con["depto_de_domicilio_ies"] == depto_de_domicilio_ies
    fig3 =  px.bar(Con[mask], x="Área de conocimiento", y="admitidos", color="sexo", title="# de admitidos por facultad")
    return fig3

 ## Viz 2 jacobo
@app.callback(
    dash.dependencies.Output('example-graph-2', 'figure'),
    dash.dependencies.Input('crossfilter_departamento2', 'value')
    )
def update_bar_chart(depto_de_domicilio_ies2):
    mask2 = Con2["depto_de_domicilio_ies"] == depto_de_domicilio_ies2
    fig2 = px.sunburst(Con2[mask2], path=["sexo","nivel_academico","caracter_ies"], values='admitidos',title = "preferencias educativas")
    return fig2

######################################################################



## viz 3 Wilmer

@app.callback(
    dash.dependencies.Output('example-graph-3', 'figure'),
    [dash.dependencies.Input('crossfilter_ciudad3', 'value')]
    )

def update_graph(ciudad_value):
    df_programa_ciudad = df_final[df_final['depto_de_domicilio_ies'] == ciudad_value]

    fig3 = px.treemap(df_programa_ciudad, path=['metodologia','semestre'],
                 values='admitidos',
                )

    return fig3

## Viz 4 Wilmer
@app.callback(
    dash.dependencies.Output('example-graph-4', 'figure'),
    [dash.dependencies.Input('crossfilter_2', 'value')]
    )
def update_graph(año_value):

    query3 = df_final[df_final['año'].isin(año_value)]
    query3 = pd.pivot_table(query3, 
                        values='admitidos',index=["sexo",'año','sector_ies'],aggfunc=np.sum)

    query3 = pd.DataFrame(query3)
    query3.reset_index(inplace=True)
    query3 = query3.sort_values(by=['admitidos'],ascending=False)
    fig4 = px.bar(query3, x='admitidos', y='sexo',color='sector_ies')

    return fig4
#####################################################################################
## viz 5 Alejandro

@app.callback(
    dash.dependencies.Output('example-graph-5', 'figure'),
    [dash.dependencies.Input('crossfilter_ciudad5', 'value')]
    )

def update_graph(instituto_value):
    df_programa_ins = df_final_bog[df_final_bog['ies'] == instituto_value]
    #df_programa_ciudad = df_final[df_final['depto_de_domicilio_ies'] == ciudad_value]

    fig5 = px.treemap(df_programa_ins, path=['nivel_de_formacion','sexo'],
                 values='admitidos',
                )

    return fig5


## Viz 6 Alejandro

## Viz MAPA D CALOR
@app.callback(
    dash.dependencies.Output('example-graph-6', 'figure'),
    [dash.dependencies.Input('crossfilter_6', 'value'),
     dash.dependencies.Input('crossfilter_mod_sex', 'value')]
    )

def update_graph(depto_value2,area_value):
    query6 = df_final[df_final['Área de conocimiento'].isin(depto_value2)]
    query6 = query6[query6['sexo'].isin(area_value)]
    
    query6 = pd.crosstab(query6["Área de conocimiento"],query6["sexo"])
    fig6 = px.imshow(query6)

    return fig6

if __name__ == "__main__":
    app.run_server(debug=True)
